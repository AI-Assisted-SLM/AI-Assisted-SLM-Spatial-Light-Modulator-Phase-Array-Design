#include "Fft.h"

#include <cmath>
#include <stdexcept>
#include <utility>

namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;

bool IsPowerOfTwo(std::size_t value) {
    return value != 0 && (value & (value - 1)) == 0;
}
}  // namespace

void FFT1D(std::vector<std::complex<double>>& values, bool inverse) {
    const std::size_t n = values.size();
    if (!IsPowerOfTwo(n)) {
        throw std::invalid_argument("FFT1D length must be a power of two");
    }

    for (std::size_t i = 1, j = 0; i < n; ++i) {
        std::size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) {
            j ^= bit;
        }
        j ^= bit;
        if (i < j) {
            std::swap(values[i], values[j]);
        }
    }

    for (std::size_t length = 2; length <= n; length <<= 1) {
        const double angle = (inverse ? 2.0 : -2.0) * kPi /
                             static_cast<double>(length);
        const std::complex<double> step(std::cos(angle), std::sin(angle));
        for (std::size_t start = 0; start < n; start += length) {
            std::complex<double> factor(1.0, 0.0);
            const std::size_t half = length >> 1;
            for (std::size_t offset = 0; offset < half; ++offset) {
                const auto even = values[start + offset];
                const auto odd = values[start + offset + half] * factor;
                values[start + offset] = even + odd;
                values[start + offset + half] = even - odd;
                factor *= step;
            }
        }
    }

    if (inverse) {
        const double scale = 1.0 / static_cast<double>(n);
        for (auto& value : values) {
            value *= scale;
        }
    }
}

void FFT2D(std::vector<std::complex<double>>& field, int size, bool inverse) {
    if (size <= 0 || !IsPowerOfTwo(static_cast<std::size_t>(size))) {
        throw std::invalid_argument("FFT2D size must be a positive power of two");
    }
    if (field.size() != static_cast<std::size_t>(size) * size) {
        throw std::invalid_argument("FFT2D field size does not match size * size");
    }

    std::vector<std::complex<double>> line(static_cast<std::size_t>(size));
    for (int y = 0; y < size; ++y) {
        for (int x = 0; x < size; ++x) {
            line[x] = field[static_cast<std::size_t>(y) * size + x];
        }
        FFT1D(line, inverse);
        for (int x = 0; x < size; ++x) {
            field[static_cast<std::size_t>(y) * size + x] = line[x];
        }
    }

    for (int x = 0; x < size; ++x) {
        for (int y = 0; y < size; ++y) {
            line[y] = field[static_cast<std::size_t>(y) * size + x];
        }
        FFT1D(line, inverse);
        for (int y = 0; y < size; ++y) {
            field[static_cast<std::size_t>(y) * size + x] = line[y];
        }
    }
}
