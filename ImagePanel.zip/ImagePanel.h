#pragma once
#include <afxwin.h>
#include <vector>

class ImagePanel : public CStatic
{
    DECLARE_DYNAMIC(ImagePanel)

public:
    ImagePanel();
    virtual ~ImagePanel();

    void SetImageData(const std::vector<double>& data, int width, int height);
    void SetPseudoColorMode(bool enable);

protected:
    afx_msg void OnPaint();
    DECLARE_MESSAGE_MAP()

private:
    std::vector<double> m_data;
    int m_width;
    int m_height;
    bool m_pseudoColor;

    void DrawGrayscale(CDC* pDC, CRect& rect);
    void DrawPseudoColor(CDC* pDC, CRect& rect);
    void DrawTestPattern(CDC* pDC, CRect& rect);
};
