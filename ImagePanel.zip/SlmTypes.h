#pragma once
#include <vector>

struct GrayImage {
    int width = 0;
    int height = 0;
    std::vector<double> data; 
};