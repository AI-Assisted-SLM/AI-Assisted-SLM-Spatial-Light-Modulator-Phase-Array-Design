#include "pch.h"
#include "PgmExporter.h"
#include <fstream>
#include <vector>

bool SavePhasePgm(const GrayImage& phase, const CString& path)
{
    if (phase.data.empty() || phase.width == 0 || phase.height == 0)
        return false;

    // CString ת std::string
    std::ofstream file((LPCTSTR)path, std::ios::binary);
    if (!file.is_open())
        return false;

    int w = phase.width;
    int h = phase.height;

    // PGM P5 ͷ
    file << "P5\n";
    file << w << " " << h << "\n";
    file << "255\n";

    // ��λ [-��, ��) �� [0, 255]
    std::vector<unsigned char> buffer(w * h);
    for (int i = 0; i < w * h; ++i) {
        double val = phase.data[i];
        int byteVal = (int)((val + 3.141592653589793) / (2 * 3.141592653589793) * 255.0);
        if (byteVal < 0) byteVal = 0;
        if (byteVal > 255) byteVal = 255;
        buffer[i] = (unsigned char)byteVal;
    }

    file.write((char*)buffer.data(), buffer.size());
    file.close();
    return true;
}