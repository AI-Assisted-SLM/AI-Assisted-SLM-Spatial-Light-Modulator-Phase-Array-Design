#pragma once

#include <stdexcept>
#include <vector>

#include "SlmTypes.h"

class SimulationCancelled final : public std::runtime_error {
public:
    SimulationCancelled() : std::runtime_error("simulation cancelled") {}
};

std::vector<double> MakeInitialPhase(
    const GrayImage& target,
    SolverMode mode);

// Throws std::invalid_argument for invalid input and SimulationCancelled when
// cancelRequested becomes true. The caller's worker thread should catch both.
SimulationResult RunSimulation(
    const GrayImage& target,
    const SimulationConfig& config,
    std::atomic_bool& cancelRequested,
    ProgressCallback onProgress);
