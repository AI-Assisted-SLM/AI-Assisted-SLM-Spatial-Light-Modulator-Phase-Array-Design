#include "SlmSolver.h"

#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <random>
#include <string>
#include <utility>

#include "Asm.h"
#include "Fft.h"
#include "Metrics.h"

namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;
constexpr double kTwoPi = 2.0 * kPi;

bool IsPowerOfTwo(int value) {
    return value > 0 && (value & (value - 1)) == 0;
}

double WrapPhase(double phase) {
    phase = std::fmod(phase + kPi, kTwoPi);
    if (phase < 0.0) {
        phase += kTwoPi;
    }
    return phase - kPi;
}

void ThrowIfCancelled(const std::atomic_bool& cancelRequested) {
    if (cancelRequested.load(std::memory_order_relaxed)) {
        throw SimulationCancelled();
    }
}

void Report(const ProgressCallback& callback,
            int percent,
            int iteration,
            const char* stage) {
    if (callback) {
        callback(ProgressInfo{std::clamp(percent, 0, 100), iteration, stage});
    }
}

GrayImage NormalizedIntensity(const GrayImage& source) {
    GrayImage result = source;
    double maximum = 0.0;
    for (double& value : result.data) {
        if (!std::isfinite(value)) {
            throw std::invalid_argument("target contains a non-finite value");
        }
        value = std::max(0.0, value);
        maximum = std::max(maximum, value);
    }
    if (!(maximum > 0.0)) {
        throw std::invalid_argument("target must contain at least one positive pixel");
    }
    for (double& value : result.data) {
        value /= maximum;
    }
    return result;
}

void NormalizeToUnitMaximum(GrayImage& image) {
    const auto maximum = std::max_element(image.data.begin(), image.data.end());
    if (maximum == image.data.end() || !(*maximum > 0.0)) {
        std::fill(image.data.begin(), image.data.end(), 0.0);
        return;
    }
    for (double& value : image.data) {
        value = std::clamp(value / *maximum, 0.0, 1.0);
    }
}

void ValidateTargetShape(const GrayImage& target) {
    if (target.width <= 0 || target.height <= 0 ||
        target.data.size() !=
            static_cast<std::size_t>(target.width) * target.height) {
        throw std::invalid_argument("target dimensions and data length do not match");
    }
}

void ValidateInputs(const GrayImage& target, const SimulationConfig& config) {
    ValidateTargetShape(target);
    if (!IsPowerOfTwo(config.size)) {
        throw std::invalid_argument("config.size must be a positive power of two");
    }
    if (target.width != config.size || target.height != config.size) {
        throw std::invalid_argument("target must be square and match config.size");
    }
    if (config.iterations <= 0) {
        throw std::invalid_argument("config.iterations must be positive");
    }
    if (config.axialSlices <= 0) {
        throw std::invalid_argument("config.axialSlices must be positive");
    }
    if (!(config.wavelength_m > 0.0) || !std::isfinite(config.wavelength_m) ||
        !(config.pixelPitch_m > 0.0) || !std::isfinite(config.pixelPitch_m) ||
        !(config.distance_m > 0.0) || !std::isfinite(config.distance_m)) {
        throw std::invalid_argument("optical parameters must be finite and positive");
    }
}

std::uint64_t HashTarget(const GrayImage& target) {
    std::uint64_t hash = 1469598103934665603ULL;
    for (double value : target.data) {
        const auto quantized = static_cast<std::uint64_t>(
            std::llround(std::clamp(value, 0.0, 1.0) * 65535.0));
        hash ^= quantized;
        hash *= 1099511628211ULL;
    }
    hash ^= static_cast<std::uint64_t>(target.width);
    hash *= 1099511628211ULL;
    return hash;
}

std::vector<std::complex<double>> PhaseOnlyField(
    const std::vector<double>& phase) {
    std::vector<std::complex<double>> field(phase.size());
    for (std::size_t i = 0; i < phase.size(); ++i) {
        field[i] = std::polar(1.0, phase[i]);
    }
    return field;
}

std::vector<double> ExtractPhase(
    const std::vector<std::complex<double>>& field) {
    std::vector<double> phase(field.size());
    for (std::size_t i = 0; i < field.size(); ++i) {
        phase[i] = WrapPhase(std::arg(field[i]));
    }
    return phase;
}

std::vector<double> MakeFastInitialPhase(const GrayImage& target) {
    const int size = target.width;
    std::vector<std::complex<double>> seededTarget(target.data.size());
    constexpr double goldenFraction = 0.6180339887498948482;

    for (int y = 0; y < size; ++y) {
        for (int x = 0; x < size; ++x) {
            const std::size_t index = static_cast<std::size_t>(y) * size + x;
            const double sequence = std::fmod(
                (static_cast<double>(index) + 0.5) * goldenFraction, 1.0);
            const double seedPhase = kTwoPi * sequence - kPi;
            seededTarget[index] =
                std::polar(std::sqrt(std::max(0.0, target.data[index])),
                           seedPhase);
        }
    }

    FFT2D(seededTarget, size, true);
    return ExtractPhase(seededTarget);
}

GrayImage BuildAxialSlice(
    const std::vector<std::complex<double>>& slmField,
    const SimulationConfig& config,
    const std::atomic_bool& cancelRequested,
    const ProgressCallback& onProgress) {
    GrayImage axial;
    axial.width = config.size;
    axial.height = config.axialSlices;
    axial.data.resize(static_cast<std::size_t>(axial.width) * axial.height);
    const int centerRow = config.size / 2;

    for (int slice = 0; slice < config.axialSlices; ++slice) {
        ThrowIfCancelled(cancelRequested);
        const double fraction = config.axialSlices == 1
            ? 0.5
            : static_cast<double>(slice) /
                  static_cast<double>(config.axialSlices - 1);
        // The displayed z range is [0.5 * target distance, 1.5 * target distance].
        const double z = config.distance_m * (0.5 + fraction);
        const auto propagated = PropagateAsm(
            slmField, config.size, config.pixelPitch_m,
            config.wavelength_m, z);
        const GrayImage intensity = IntensityOf(propagated, config.size);
        for (int x = 0; x < config.size; ++x) {
            axial.data[static_cast<std::size_t>(slice) * config.size + x] =
                intensity.data[static_cast<std::size_t>(centerRow) *
                                   config.size + x];
        }
        const int percent = 80 + (19 * (slice + 1)) / config.axialSlices;
        Report(onProgress, percent, config.iterations, "计算轴向剖面");
    }

    NormalizeToUnitMaximum(axial);
    return axial;
}
}  // namespace

std::vector<double> MakeInitialPhase(
    const GrayImage& target,
    SolverMode mode) {
    ValidateTargetShape(target);
    if (target.width != target.height || !IsPowerOfTwo(target.width)) {
        throw std::invalid_argument(
            "initial phase target must be square with a power-of-two size");
    }
    const GrayImage normalized = NormalizedIntensity(target);

    if (mode == SolverMode::AiFastSearch) {
        return MakeFastInitialPhase(normalized);
    }

    std::mt19937_64 generator(HashTarget(normalized));
    std::uniform_real_distribution<double> distribution(-kPi, kPi);
    std::vector<double> phase(normalized.data.size());
    for (double& value : phase) {
        value = WrapPhase(distribution(generator));
    }
    return phase;
}

SimulationResult RunSimulation(
    const GrayImage& target,
    const SimulationConfig& config,
    std::atomic_bool& cancelRequested,
    ProgressCallback onProgress) {
    ValidateInputs(target, config);
    ThrowIfCancelled(cancelRequested);
    const GrayImage normalizedTarget = NormalizedIntensity(target);
    const std::size_t pixelCount = normalizedTarget.data.size();
    std::vector<double> targetAmplitude(pixelCount);
    std::transform(normalizedTarget.data.begin(), normalizedTarget.data.end(),
                   targetAmplitude.begin(),
                   [](double intensity) { return std::sqrt(intensity); });

    Report(onProgress, 0, 0, "准备初始相位");
    std::vector<double> phase = MakeInitialPhase(normalizedTarget, config.mode);

    for (int iteration = 0; iteration < config.iterations; ++iteration) {
        ThrowIfCancelled(cancelRequested);
        auto targetField = PropagateAsm(
            PhaseOnlyField(phase), config.size, config.pixelPitch_m,
            config.wavelength_m, config.distance_m);

        for (std::size_t i = 0; i < pixelCount; ++i) {
            targetField[i] = std::polar(targetAmplitude[i],
                                        std::arg(targetField[i]));
        }

        const auto returnedField = PropagateAsm(
            std::move(targetField), config.size, config.pixelPitch_m,
            config.wavelength_m, -config.distance_m);
        const std::vector<double> candidate = ExtractPhase(returnedField);

        if (config.mode == SolverMode::GS) {
            phase = candidate;
        } else {
            // Deterministic successive over-relaxation: larger early updates,
            // gradually converging to the ordinary GS update near the end.
            const double progress = static_cast<double>(iteration + 1) /
                                    static_cast<double>(config.iterations);
            const double relaxation = 1.15 - 0.15 * progress;
            for (std::size_t i = 0; i < pixelCount; ++i) {
                const double delta = WrapPhase(candidate[i] - phase[i]);
                phase[i] = WrapPhase(phase[i] + relaxation * delta);
            }
        }

        const int percent = 5 + (70 * (iteration + 1)) / config.iterations;
        Report(onProgress, percent, iteration + 1,
               config.mode == SolverMode::GS ? "GS迭代" : "快速搜索迭代");
    }

    ThrowIfCancelled(cancelRequested);
    Report(onProgress, 78, config.iterations, "计算重建结果");
    const auto slmField = PhaseOnlyField(phase);
    const auto finalField = PropagateAsm(
        slmField, config.size, config.pixelPitch_m,
        config.wavelength_m, config.distance_m);

    SimulationResult result;
    result.phase.width = config.size;
    result.phase.height = config.size;
    result.phase.data = std::move(phase);
    result.reconstruction = IntensityOf(finalField, config.size);
    NormalizeToUnitMaximum(result.reconstruction);
    result.mse = ComputeMse(normalizedTarget, result.reconstruction);
    result.psnr = ComputePsnr(result.mse);
    result.axial = BuildAxialSlice(
        slmField, config, cancelRequested, onProgress);

    ThrowIfCancelled(cancelRequested);
    Report(onProgress, 100, config.iterations, "完成");
    return result;
}
