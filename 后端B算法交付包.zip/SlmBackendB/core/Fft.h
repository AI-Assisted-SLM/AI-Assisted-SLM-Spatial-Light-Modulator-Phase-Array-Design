#pragma once

#include <complex>
#include <vector>

void FFT1D(std::vector<std::complex<double>>& values, bool inverse);
void FFT2D(std::vector<std::complex<double>>& field, int size, bool inverse);
