#include "Asm.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>

#include "Fft.h"

namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;
}

std::vector<std::complex<double>> PropagateAsm(
    std::vector<std::complex<double>> field,
    int size,
    double pixelPitch_m,
    double wavelength_m,
    double distance_m) {
    if (size <= 0 || field.size() != static_cast<std::size_t>(size) * size) {
        throw std::invalid_argument("ASM field size does not match size * size");
    }
    if (!(pixelPitch_m > 0.0) || !(wavelength_m > 0.0) ||
        !std::isfinite(distance_m)) {
        throw std::invalid_argument("ASM optical parameters are invalid");
    }

    FFT2D(field, size, false);
    const double invLambdaSquared = 1.0 / (wavelength_m * wavelength_m);
    const double frequencyStep = 1.0 / (static_cast<double>(size) * pixelPitch_m);

    for (int y = 0; y < size; ++y) {
        const int fyIndex = (y <= size / 2) ? y : y - size;
        const double fy = static_cast<double>(fyIndex) * frequencyStep;
        for (int x = 0; x < size; ++x) {
            const int fxIndex = (x <= size / 2) ? x : x - size;
            const double fx = static_cast<double>(fxIndex) * frequencyStep;
            const double propagatingPart = invLambdaSquared - fx * fx - fy * fy;
            auto& spectrum = field[static_cast<std::size_t>(y) * size + x];
            if (propagatingPart <= 0.0) {
                spectrum = {0.0, 0.0};
                continue;
            }
            const double phase = 2.0 * kPi * distance_m *
                                 std::sqrt(propagatingPart);
            spectrum *= std::complex<double>(std::cos(phase), std::sin(phase));
        }
    }

    FFT2D(field, size, true);
    return field;
}

GrayImage IntensityOf(
    const std::vector<std::complex<double>>& field,
    int size) {
    if (size <= 0 || field.size() != static_cast<std::size_t>(size) * size) {
        throw std::invalid_argument("Intensity field size does not match size * size");
    }

    GrayImage result;
    result.width = size;
    result.height = size;
    result.data.resize(field.size());
    std::transform(field.begin(), field.end(), result.data.begin(),
                   [](const std::complex<double>& value) {
                       return std::norm(value);
                   });
    return result;
}
