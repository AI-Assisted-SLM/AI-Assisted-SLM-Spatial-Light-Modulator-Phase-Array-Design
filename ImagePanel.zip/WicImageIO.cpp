#include "pch.h"
#include "WicImageIO.h"
#include <wincodec.h>
#include <atlbase.h>

#pragma comment(lib, "windowscodecs.lib")

bool LoadImageWithWic(const CString& path, int targetSize,
    GrayImage& output, CString& error)
{
    // ��ʼ�� COM
    HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    bool comInitialized = SUCCEEDED(hr);
    if (hr == S_FALSE) comInitialized = true; // �Ѿ���ʼ������

    IWICImagingFactory* pFactory = NULL;
    hr = CoCreateInstance(CLSID_WICImagingFactory, NULL,
        CLSCTX_INPROC_SERVER, IID_IWICImagingFactory,
        (LPVOID*)&pFactory);
    if (FAILED(hr)) {
        error = L"�޷����� WIC ����";
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    // ����ͼƬ
    IWICBitmapDecoder* pDecoder = NULL;
    hr = pFactory->CreateDecoderFromFilename(
        path, NULL, GENERIC_READ, WICDecodeMetadataCacheOnLoad, &pDecoder);
    if (FAILED(hr)) {
        error = L"�޷�����ͼƬ���ļ���ʽ��֧�ֻ����𻵣�";
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    IWICBitmapFrameDecode* pFrame = NULL;
    hr = pDecoder->GetFrame(0, &pFrame);
    if (FAILED(hr)) {
        error = L"�޷���ȡͼƬ֡";
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    // ��ȡԭʼ�ߴ�
    UINT srcWidth, srcHeight;
    pFrame->GetSize(&srcWidth, &srcHeight);

    // ת��Ϊ�Ҷ�
    IWICFormatConverter* pConverter = NULL;
    hr = pFactory->CreateFormatConverter(&pConverter);
    if (FAILED(hr)) {
        error = L"�޷�������ʽת����";
        pFrame->Release();
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    hr = pConverter->Initialize(pFrame, GUID_WICPixelFormat8bppGray,
        WICBitmapDitherTypeNone, NULL, 0.0,
        WICBitmapPaletteTypeCustom);
    if (FAILED(hr)) {
        error = L"�޷�ת��Ϊ�Ҷ�ͼ";
        pConverter->Release();
        pFrame->Release();
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    // ���ŵ� targetSize
    IWICBitmapScaler* pScaler = NULL;
    hr = pFactory->CreateBitmapScaler(&pScaler);
    if (FAILED(hr)) {
        error = L"�޷�����������";
        pConverter->Release();
        pFrame->Release();
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    hr = pScaler->Initialize(pConverter, targetSize, targetSize,
        WICBitmapInterpolationModeFant);
    if (FAILED(hr)) {
        error = L"�޷�����ͼƬ";
        pScaler->Release();
        pConverter->Release();
        pFrame->Release();
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    // ��ȡ����
    output.width = targetSize;
    output.height = targetSize;
    output.data.resize(targetSize * targetSize);

    WICRect rect = { 0, 0, targetSize, targetSize };
    hr = pScaler->CopyPixels(&rect, targetSize, targetSize * targetSize,
        (BYTE*)output.data.data());
    if (FAILED(hr)) {
        error = L"�޷���ȡ��������";
        pScaler->Release();
        pConverter->Release();
        pFrame->Release();
        pDecoder->Release();
        pFactory->Release();
        if (comInitialized && hr != S_FALSE) CoUninitialize();
        return false;
    }

    // ��һ���� 0~1
    for (double& v : output.data) {
        v /= 255.0;
    }

    // �ͷ���Դ
    pScaler->Release();
    pConverter->Release();
    pFrame->Release();
    pDecoder->Release();
    pFactory->Release();
    if (comInitialized && hr != S_FALSE) CoUninitialize();

    error = L"";
    return true;
}