#include "pch.h"
#include "ImageUtils.h"
#include <algorithm>
#include <cmath>

void Normalize(GrayImage& image) {
    if (image.data.empty()) return;

    double minVal = *std::min_element(image.data.begin(), image.data.end());
    double maxVal = *std::max_element(image.data.begin(), image.data.end());

    double range = maxVal - minVal;
    if (range < 1e-12) {
        std::fill(image.data.begin(), image.data.end(), 0.5);
        return;
    }

    for (double& v : image.data) {
        v = (v - minVal) / range;
    }
}

GrayImage MakeDotArray(int size) {
    GrayImage result;
    result.width = size;
    result.height = size;
    result.data.resize(size * size, 0.0);

    int dotsPerRow = 9;
    double spacing = (double)size / (dotsPerRow + 1);
    double sigma = spacing / 6.0;

    for (int row = 0; row < dotsPerRow; ++row) {
        for (int col = 0; col < dotsPerRow; ++col) {
            double cx = spacing * (col + 1);
            double cy = spacing * (row + 1);

            for (int y = 0; y < size; ++y) {
                for (int x = 0; x < size; ++x) {
                    double dx = x - cx;
                    double dy = y - cy;
                    double val = std::exp(-(dx * dx + dy * dy) / (2 * sigma * sigma));
                    result.data[y * size + x] += val;
                }
            }
        }
    }

    for (double& v : result.data) {
        if (v > 1.0) v = 1.0;
    }

    return result;
}

GrayImage ResizeToSquare(const GrayImage& image, int size) {
    GrayImage result;
    result.width = size;
    result.height = size;
    result.data.resize(size * size, 0.0);

    if (image.width == 0 || image.height == 0) return result;

    double scaleX = (double)image.width / size;
    double scaleY = (double)image.height / size;

    for (int y = 0; y < size; ++y) {
        for (int x = 0; x < size; ++x) {
            int srcX = (int)(x * scaleX);
            int srcY = (int)(y * scaleY);
            if (srcX >= image.width) srcX = image.width - 1;
            if (srcY >= image.height) srcY = image.height - 1;
            result.data[y * size + x] = image.data[srcY * image.width + srcX];
        }
    }

    return result;
}