#include "pch.h"
#include "ImagePanel.h"

IMPLEMENT_DYNAMIC(ImagePanel, CStatic)

ImagePanel::ImagePanel()
    : m_width(0), m_height(0), m_pseudoColor(false)
{
}

ImagePanel::~ImagePanel()
{
}

BEGIN_MESSAGE_MAP(ImagePanel, CStatic)
    ON_WM_PAINT()
END_MESSAGE_MAP()

void ImagePanel::SetImageData(const std::vector<double>& data, int width, int height)
{
    
    m_data = data;
    m_width = width;
    m_height = height;

    Invalidate();
}

void ImagePanel::SetPseudoColorMode(bool enable)
{
    m_pseudoColor = enable;
    Invalidate();
}

void ImagePanel::OnPaint()
{
   
    CPaintDC dc(this);
    CRect rect;
    GetClientRect(&rect);

    if (m_data.empty() || m_width == 0 || m_height == 0) {
        DrawTestPattern(&dc, rect);
        return;
    }

    if (m_pseudoColor) {
        DrawPseudoColor(&dc, rect);
    }
    else {
        DrawGrayscale(&dc, rect);
    }
}

void ImagePanel::DrawGrayscale(CDC* pDC, CRect& rect)
{

    int panelW = rect.Width();
    int panelH = rect.Height();



    CDC memDC;
    memDC.CreateCompatibleDC(pDC);
    CBitmap bitmap;
    bitmap.CreateCompatibleBitmap(pDC, panelW, panelH);
    memDC.SelectObject(&bitmap);

    for (int y = 0; y < panelH; y++) {
        for (int x = 0; x < panelW; x++) {
            int srcX = (x * m_width) / panelW;
            int srcY = (y * m_height) / panelH;
            double val = m_data[srcY * m_width + srcX];
            if (val < 0) val = 0;
            if (val > 1) val = 1;
            unsigned char gray = (unsigned char)(val * 255);
            memDC.SetPixelV(x, y, RGB(gray, gray, gray));
        }
    }

    pDC->BitBlt(0, 0, panelW, panelH, &memDC, 0, 0, SRCCOPY);
}

void ImagePanel::DrawPseudoColor(CDC* pDC, CRect& rect)
{

    int panelW = rect.Width();
    int panelH = rect.Height();



    CDC memDC;
    memDC.CreateCompatibleDC(pDC);
    CBitmap bitmap;
    bitmap.CreateCompatibleBitmap(pDC, panelW, panelH);
    memDC.SelectObject(&bitmap);

    for (int y = 0; y < panelH; y++) {
        for (int x = 0; x < panelW; x++) {
            int srcX = (x * m_width) / panelW;
            int srcY = (y * m_height) / panelH;
            double val = m_data[srcY * m_width + srcX];

            double t = (val + 3.141592653589793) / (2 * 3.141592653589793);
            if (t < 0) t = 0;
            if (t >= 1) t = 0.999;

            unsigned char r, g, b;
            if (t < 0.25) {
                r = 0;
                g = (unsigned char)(t * 4 * 255);
                b = 255;
            }
            else if (t < 0.5) {
                r = 0;
                g = 255;
                b = (unsigned char)((1 - (t - 0.25) * 4) * 255);
            }
            else if (t < 0.75) {
                r = (unsigned char)((t - 0.5) * 4 * 255);
                g = 255;
                b = 0;
            }
            else {
                r = 255;
                g = (unsigned char)((1 - (t - 0.75) * 4) * 255);
                b = 0;
            }
            memDC.SetPixelV(x, y, RGB(r, g, b));
        }
    }

    pDC->BitBlt(0, 0, panelW, panelH, &memDC, 0, 0, SRCCOPY);
}

void ImagePanel::DrawTestPattern(CDC* pDC, CRect& rect)
{

    int panelW = rect.Width();
    int panelH = rect.Height();

    for (int y = 0; y < panelH; y++) {
        for (int x = 0; x < panelW; x++) {
            int blockSize = 20;
            bool white = ((x / blockSize) + (y / blockSize)) % 2 == 0;
            COLORREF color = white ? RGB(200, 200, 200) : RGB(100, 100, 100);
            pDC->SetPixelV(x, y, color);
        }
    }

    CPen pen(PS_SOLID, 1, RGB(0, 0, 0));
    pDC->SelectObject(&pen);
    pDC->MoveTo(0, 0);
    pDC->LineTo(panelW - 1, 0);
    pDC->LineTo(panelW - 1, panelH - 1);
    pDC->LineTo(0, panelH - 1);
    pDC->LineTo(0, 0);
}