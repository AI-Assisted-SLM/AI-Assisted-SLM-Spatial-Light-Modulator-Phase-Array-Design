#include "Metrics.h"

#include <cmath>
#include <limits>
#include <stdexcept>

double ComputeMse(const GrayImage& expected, const GrayImage& actual) {
    if (expected.width != actual.width || expected.height != actual.height ||
        expected.data.size() != actual.data.size() || expected.data.empty()) {
        throw std::invalid_argument("MSE images must have matching non-empty dimensions");
    }

    double squaredError = 0.0;
    for (std::size_t i = 0; i < expected.data.size(); ++i) {
        const double difference = expected.data[i] - actual.data[i];
        squaredError += difference * difference;
    }
    return squaredError / static_cast<double>(expected.data.size());
}

double ComputePsnr(double mse) {
    if (mse < 0.0 || !std::isfinite(mse)) {
        throw std::invalid_argument("MSE must be finite and non-negative");
    }
    if (mse == 0.0) {
        return std::numeric_limits<double>::infinity();
    }
    return 10.0 * std::log10(1.0 / mse);
}
