#pragma once
#include "SlmTypes.h"
#include <atlstr.h>

bool SavePhasePgm(const GrayImage& phase, const CString& path);
