#include <algorithm>
#include <atomic>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "SlmSolver.h"

namespace {
constexpr double kPi = 3.141592653589793238462643383279502884;

void Check(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

GrayImage MakeNineSpotTarget(int size) {
    GrayImage target{size, size,
                     std::vector<double>(static_cast<std::size_t>(size) * size)};
    const int centers[] = {size / 4, size / 2, 3 * size / 4};
    const double sigma = std::max(1.0, size / 48.0);
    for (int cy : centers) {
        for (int cx : centers) {
            for (int y = 0; y < size; ++y) {
                for (int x = 0; x < size; ++x) {
                    const double dx = static_cast<double>(x - cx);
                    const double dy = static_cast<double>(y - cy);
                    target.data[static_cast<std::size_t>(y) * size + x] +=
                        std::exp(-(dx * dx + dy * dy) /
                                 (2.0 * sigma * sigma));
                }
            }
        }
    }
    return target;
}

void TestInitialPhase() {
    const GrayImage target = MakeNineSpotTarget(16);
    const auto gsA = MakeInitialPhase(target, SolverMode::GS);
    const auto gsB = MakeInitialPhase(target, SolverMode::GS);
    const auto fast = MakeInitialPhase(target, SolverMode::AiFastSearch);
    Check(gsA.size() == target.data.size(), "GS initial phase size mismatch");
    Check(gsA == gsB, "GS initial phase is not deterministic");
    Check(fast.size() == target.data.size(), "fast initial phase size mismatch");
    Check(gsA != fast, "the two modes unexpectedly use the same initial phase");
    for (double phase : fast) {
        Check(std::isfinite(phase), "initial phase is not finite");
        Check(phase >= -kPi && phase < kPi, "initial phase is out of range");
    }
}

void TestValidation() {
    GrayImage invalid{8, 8, std::vector<double>(63, 1.0)};
    bool thrown = false;
    try {
        (void)MakeInitialPhase(invalid, SolverMode::GS);
    } catch (const std::invalid_argument&) {
        thrown = true;
    }
    Check(thrown, "invalid target data length was accepted");
}

void TestCancellation() {
    const GrayImage target = MakeNineSpotTarget(16);
    SimulationConfig config;
    config.size = 16;
    config.iterations = 2;
    config.axialSlices = 3;
    std::atomic_bool cancelled{true};
    bool thrown = false;
    try {
        (void)RunSimulation(target, config, cancelled, {});
    } catch (const SimulationCancelled&) {
        thrown = true;
    }
    Check(thrown, "pre-cancelled simulation did not stop");
}

void TestSimulation(SolverMode mode) {
    constexpr int size = 32;
    const GrayImage target = MakeNineSpotTarget(size);
    SimulationConfig config;
    config.size = size;
    config.iterations = mode == SolverMode::GS ? 10 : 8;
    config.axialSlices = 7;
    config.mode = mode;

    std::atomic_bool cancelled{false};
    std::vector<int> progress;
    const SimulationResult result = RunSimulation(
        target, config, cancelled,
        [&](const ProgressInfo& info) {
            Check(info.percent >= 0 && info.percent <= 100,
                  "progress percent is out of range");
            Check(!info.stage.empty(), "progress stage is empty");
            progress.push_back(info.percent);
        });

    Check(result.phase.width == size && result.phase.height == size,
          "phase dimensions are wrong");
    Check(result.phase.data.size() == static_cast<std::size_t>(size) * size,
          "phase data length is wrong");
    Check(result.reconstruction.width == size &&
              result.reconstruction.height == size,
          "reconstruction dimensions are wrong");
    Check(result.axial.width == size &&
              result.axial.height == config.axialSlices,
          "axial dimensions are wrong");
    Check(std::isfinite(result.mse) && result.mse >= 0.0,
          "MSE is invalid");
    Check(std::isfinite(result.psnr) && result.psnr > 0.0,
          "PSNR is invalid");
    Check(!progress.empty() && progress.front() == 0 && progress.back() == 100,
          "progress endpoints are wrong");
    Check(std::is_sorted(progress.begin(), progress.end()),
          "progress is not monotonic");
    for (double phase : result.phase.data) {
        Check(std::isfinite(phase), "result phase is not finite");
        Check(phase >= -kPi && phase < kPi, "result phase is out of range");
    }
    for (double intensity : result.reconstruction.data) {
        Check(std::isfinite(intensity), "reconstruction is not finite");
        Check(intensity >= 0.0 && intensity <= 1.0,
              "reconstruction intensity is out of range");
    }

    std::cout << (mode == SolverMode::GS ? "GS" : "AiFastSearch")
              << ": MSE=" << result.mse
              << ", PSNR=" << result.psnr << " dB\n";
}
}  // namespace

int main() {
    TestInitialPhase();
    TestValidation();
    TestCancellation();
    TestSimulation(SolverMode::GS);
    TestSimulation(SolverMode::AiFastSearch);
    std::cout << "All backend B smoke tests passed.\n";
    return 0;
}
