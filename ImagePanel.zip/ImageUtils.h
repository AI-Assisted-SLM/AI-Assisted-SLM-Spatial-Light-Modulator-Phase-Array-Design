#pragma once
#include "SlmTypes.h"

GrayImage MakeDotArray(int size);
void Normalize(GrayImage& image);
GrayImage ResizeToSquare(const GrayImage& image, int size);