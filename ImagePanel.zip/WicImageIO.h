#pragma once
#include "SlmTypes.h"
#include <atlstr.h>

bool LoadImageWithWic(const CString& path, int targetSize,
    GrayImage& output, CString& error);