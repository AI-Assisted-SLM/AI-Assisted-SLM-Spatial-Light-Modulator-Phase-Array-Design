#pragma once

#include "SlmTypes.h"

double ComputeMse(const GrayImage& expected, const GrayImage& actual);
double ComputePsnr(double mse);
