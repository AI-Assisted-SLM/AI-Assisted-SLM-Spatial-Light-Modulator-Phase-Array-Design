#pragma once

#include <complex>
#include <vector>

#include "SlmTypes.h"

std::vector<std::complex<double>> PropagateAsm(
    std::vector<std::complex<double>> field,
    int size,
    double pixelPitch_m,
    double wavelength_m,
    double distance_m);

GrayImage IntensityOf(
    const std::vector<std::complex<double>>& field,
    int size);
